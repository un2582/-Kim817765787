﻿using BooksoftheDay.Models;
using System;
using System.Linq;

namespace BooksoftheDay.Data
{
    public static class DbInitializer
    {
        public static void Initialize(BookContext context)
        {
            context.Database.EnsureCreated();

            // Look for any students.
            if (context.Books.Any())
            {
                return;   // DB has been seeded
            }
            //If no books found, create some random seed data
            var books = new Book[]
            {
            new Book{AuthorLastName="Chang", AuthorFirstName="Jessica", Title="The Hungry Games", Genre="Comedy",Price=20.99M},
            new Book{AuthorLastName="Brown", AuthorFirstName="Ryan", Title="The Great Batsby", Genre="Horror",Price=18.00M},
            new Book{AuthorLastName="Hassad", AuthorFirstName="Kalif", Title="Moby Duck", Genre="Action",Price=15.99M},
            new Book{AuthorLastName="Green", AuthorFirstName="Leaf", Title="To kill a bird", Genre="Thriller",Price=20.99M},
            new Book{AuthorLastName="Kingham", AuthorFirstName="Ricky", Title="He was Brad", Genre="Comedy",Price=25.99M}
            };
            foreach (Book b in books)
            {
                context.Books.Add(b);
            }
            context.SaveChanges();
        }


    }
}